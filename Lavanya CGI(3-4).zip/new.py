#!C:\Users\LAVANYA\AppData\Local\Programs\Python\Python310\python.exe

import cgi,cgitb

cgitb.enable()

a=cgi.FieldStorage()




print ("Content-type:text/html\n")

print("<html>")

print("<body>")

print("<h1 style='font-size: 4rem'> Welcome! </h1>")

print("<h2 style='color: #DC143C'> Fly high stay safe </h2>")

print("<style>")

print('''body {
    background-image: url('https://www.informalnewz.com/wp-content/webp-express/webp-images/uploads/2022/08/Flight-Ticket-696x464.jpg.webp');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
    
}''')

print("</style>")

print("<form>")

print("<table  cellpadding=20 align=center>")

print("<tr>")

print("<td><img height=70px width=80px src='https://thumbs.dreamstime.com/z/letter-logo-airplane-air-airplane-minimalistic-logo-design-airplane-icon-vector-illustration-design-logo-template-aviator-155983527.jpg'></td>")

print("<td><font size=7 color='#0000CD'>Ashla Airways</font></td>")

print("<td>")

print("<select>")

print("<option value='India'>India</option>")

print("<option value='America'>America</option>")

print("<option value='Russia'>Russia</option>")

print("<option value='Malaysia'>Malaysia</option>")

print("</select>")

print("</td>")

print("</tr>")

print("</table>")

print("<table border=2 cellpadding=10 cellspacing=10  align=center>")

print("<tr>")

print("<td><font size=5><a href='home.py' target='f3'>Home</a></font></td>")

print("<td><font size=5><a href='trip.py' target='f3'>Manage Your Trip</a></font></td>")

print("</tr>")

print("</table>")

print("</form>")

print("</body>")


print("</html>")

